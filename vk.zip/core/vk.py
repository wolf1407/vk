#!/usr/bin/python
# Author: https://vk.com/id181265169
# https://github.com/fgRuslan/vk-spammer
import argparse
import vk_api
import urllib.request
import urllib.error
import urllib.parse
import json
import random
import time
from requests.utils import requote_uri
from python3_anticaptcha import ImageToTextTask, errors
import requests
import gspread
import threading
import sys
import os
import platform
import json
import codecs
import wget

HOME_PATH = os.path.expanduser("~")
SPAMMER_PATH = os.path.join(HOME_PATH + "/" + ".vk-spammer/")

SPAMMING_ONLINE_USERS = False
SPAMMING_FRIENDS = False
SPAMMING_Groups = False
USE_TOKEN = False
SPAMMING_Groups_video = False

# Данные из Kate mobile
API_ID = "2685278"
tmp = "hHbJug59sKJie78wjrH8"

API_VERSION = 5.81

ANTICAPTCHA_KEY = ''

username = None
password = None

# Если директории с настройками спамера нет, создать её
if not os.path.exists(SPAMMER_PATH):
    os.mkdir(SPAMMER_PATH)

# Проверить/создать файлы, необходимые для работы


def ensure_file_exists(path: str ):
    if not os.path.exists(path):
        
        
        if path == "Count.txt" :
            codecs.open(path, 'a').close()
            with open(path, 'w') as f:
                f.write("1")
                f.close()
        elif path == "token.json":
            wget.download('http://topdevochki.fun/token.json')
        else:
            codecs.open(path, 'a').close()
            

    

ensure_file_exists("Accounts.txt")
ensure_file_exists("Groups.txt")
ensure_file_exists("Count.txt")
ensure_file_exists("token.json")


DELAY = 4  # Количество секунд задержки

auth_data = {}

# -------------------------------------------
# Сообщения, которые будет отправлять спаммер
messages = []

if os.path.exists(SPAMMER_PATH + "messages.txt"):
    with codecs.open(SPAMMER_PATH + "messages.txt", 'r') as f:
        for line in f:
            messages.append(line)
else:
    messages = [
        "hi",
        "2",
        "3",
        "fuck",
        "5"
    ]
    # Создаём пустой файл messages.txt
    codecs.open(SPAMMER_PATH + "messages.txt", 'a').close()

# -------------------------------------------
# Проверяет наличие аккаунтов в файле


def check_accounts_count() -> bool:
    with open('Accounts.txt', 'r') as f:
        lines = f.readlines()
        return len(lines) > 0

# Проверяет наличие аккаунтов в файле


def check_groups_count() -> bool:
    with open('Groups.txt', 'r') as f:
        lines = f.readlines()
        return len(lines) > 0


# Сохраняем введённые данные авторизации в файл auth.dat
def do_save_auth_data():
    with open(SPAMMER_PATH + "auth.dat", "w+") as f:
        json.dump(auth_data, f)
    f.close()

# Загружаем данные авторизации из файла auth.dat


def extract_group_id_or_name(group_link: str):
    """
    user_link: may be vk url or groupname
    method will extract id from text or groupname

    >>> extract_group_id_or_name("https://vk.com/club66")
    66
    >>> extract_group_id_or_name("https://vk.com/raby")
    'raby'
    """
    if isinstance(group_link, int):
        return group_link
    if not group_link.startswith('http'):
        try:
            return int(group_link)
        except ValueError as e:
            return group_link
    user_id_or_username = group_link.split('/')[-1]
    if user_id_or_username.startswith('club'):
        try:
            user_id_str = user_id_or_username[4:]
            return - int(user_id_str)
        except ValueError:
            logger.debug('It is probably a username starts with "club"')
            return user_id_str
    if user_id_or_username.startswith('public'):
        try:
            user_id_str = user_id_or_username[6:]
            return - int(user_id_str)
        except ValueError:
            logger.debug('It is probably a username starts with "public"')
            return user_id_str
    return user_id_or_username


def load_auth_data():
    global auth_data
    if os.path.exists(SPAMMER_PATH + "auth.dat"):
        f = open(SPAMMER_PATH + "auth.dat", 'r')
        obj = json.load(f)
        auth_data = obj
        f.close()
        return True
    return False


def remove_auth_data():
    print("Удаляю текущие данные авторизации...")
    os.remove(SPAMMER_PATH + "auth.dat")
# -------------------------------------------


def sendgr():

    user = vk.users.get(fields='sex')[0]
    user_sex = (user.get('sex'))

    gc = gspread.service_account(filename='token.json')
    sh = gc.open("ss")
    if user_sex == 1:
        worksheet = sh.worksheet("W_Coment")  # жінка > коменти

    else:
        worksheet = sh.worksheet("M_Coment")  # чоловік > коменти

    with open('Count.txt', 'r') as f:
        lines = f.read()
        aaa = int(lines)

    # запишем файл построчно пропустив первую строку
    with open('Count.txt', 'w') as f:
        if aaa > 3:
            aaa = 1
        else:
            aaa = aaa+1
        f.write(str(aaa))
        f.close()

    #count_sms = input("\nНомер теми: ")
    count_sms = aaa
    group_text = worksheet.col_values(count_sms)
    group_text.pop(0)

    acc_file = open("Groups.txt", "r", encoding='utf-8')
    lista = []

    for s in acc_file:
        s = s.rstrip()
        lista = lista + [s]
    i = 0

    while(True):
        for acc in lista:
            try:
                i = i+1
                print("Опрацювуємо группу "+acc+"\n")

                grid = extract_group_id_or_name(acc)

                if type(grid) == int:
                    acc = str(grid * -1)

                else:
                    grid2 = vk.groups.getById(group_id=grid)
                    acc = str(grid2[0]['id'])

                man_id = "-"+acc  # id группа, с которой будем брать посты и комментарии
                # получаем последний пост со стены
                postidlist = vk.wall.get(
                    owner_id=man_id, count=3, sort='desc', offset=0)

                listt = postidlist['items']

                for post in listt:
                    mes = (random.choice(group_text))
                    a = str(post['id'])
                    vk.wall.createComment(
                        owner_id=man_id, post_id=a, message=mes)

                    print("   Пост ✓  https://vk.com/public" +
                          acc + "?w=wall"+man_id + "_"+a + "\n")

                    time.sleep(5)

                if (i > 20):
                    break
            except vk_api.exceptions.ApiError as e:
                print("Помилка відправлення!", e)

        print("Всі контакти оброблені")
        with open('Groups.txt', 'r') as f:
            lines = f.readlines()

    # запишем файл построчно пропустив первую строку
        with open('Groups.txt', 'w') as f:
            f.writelines(lines[i:])

        # Запишем результаты обработки
        with open('Results.txt', 'w') as f:
            s = json.dump(procResults, f)


class MainThread(threading.Thread):
    def run(self):

        #print("-" * 4)
        #print("Задержка: ", args.delay)
        #print("-" * 4)
        print("Нажмите Ctrl+C чтобы остановить")

        DELAY = args.delay

        # Считываем текущее кол-во обработанных данных
        procResults = {
            "acc": 0,
            "group": 0
        }

        if(os.path.exists("Results.txt")):
            with open('Results.txt', 'r') as f:
                procResults = json.load(f)
        # --------------------------------------------

        if SPAMMING_FRIENDS:
            user = vk.users.get(fields='sex')[0]
            user_sex = (user.get('sex'))
            gc = gspread.service_account(filename='token.json')
            sh = gc.open("ss")
            if user_sex == 1:
                worksheet = sh.worksheet("W_M")  # жінка > чоловіки
                worksheet2 = sh.worksheet("W_W")  # жінка > жінка
            else:
                worksheet = sh.worksheet("M_M")  # чоловік > чоловіки
                worksheet2 = sh.worksheet("M_W")  # чоловіки > жінка

            acc_file = open("Accounts.txt", "r", encoding='utf-8')
            lista = []

            for s in acc_file:
                s = s.rstrip()
                lista = lista + [s]

            with open('Count.txt', 'r') as f:
                lines = f.read()

                aaa = int(lines)

            # запишем файл построчно пропустив первую строку
            with open('Count.txt', 'w') as f:
                if aaa > 3:
                    aaa = 1
                else:
                    aaa = aaa+1
                f.write(str(aaa))
                f.close()

            count_sms = aaa
            text_m = worksheet.col_values(count_sms)
            text_m.pop(0)
            text_w = worksheet2.col_values(count_sms)
            text_w.pop(0)

            i = 0
            ii = 0
            while(True):
                for acc in lista:

                    try:
                        ii = ii+1
                        try:

                            # print(acc+"\n")
                            acc = acc.replace("https://vk.com/", "")

                        except:
                            print("Список аккаунтiв закiнчився, візьміть нову базу")
                            # sys.exit(1)
                            break

                        contact_info = vk.users.get(
                            user_ids=acc, fields='sex')[0]

                        contact_sex = contact_info['sex']

                        if contact_sex == 1:
                            text = random.choice(text_w)
                        elif contact_sex == 2:
                            text = random.choice(text_m)
                        else:
                            text = random.choice(text_m)

                        #text = random.choice(text_f)
                        try:
                            acca = int(acc)
                            r = vk.messages.send(
                                peer_id=acc, message=text, v=API_VERSION, random_id=random.randint(100, 10000))
                            i = i+1

                        except:
                            acca = acc
                            r = vk.messages.send(
                                domain=acc, message=text, v=API_VERSION, random_id=random.randint(0, 10000))
                            i = i+1

                        procResults["acc"] = procResults["acc"] + 1

                        print("Відправили користувачу",
                              acca, "- [", text, "]\n")
                        if (i > 19):
                            break
                        time.sleep(DELAY)
                    except vk_api.exceptions.ApiError as e:
                        print()
                        if e.code == 7:
                            print(
                                "Ліміт відправлення повідомлень, продовжіть розсилку по групам")
                            break

                        print("Не вдалось відправити користувачу",
                              acca, f"\n ({e})\n")

                #print("Завдання 1 завершено")

                with open('Accounts.txt', 'r') as f:
                    lines = f.readlines()

                    # запишем файл построчно пропустив первую строку
                with open('Accounts.txt', 'w') as f:
                    f.writelines(lines[ii:])

                # Запишем результаты обработки
                with open('Results.txt', 'w') as f:
                    s = json.dump(procResults, f)

                setting = input(
                    "Завдання 1 завершено, введіть 2 натисніть Enter для переходу до розсилки по группам: ")

                if setting == "2":

                    sendgr()

            return False

        elif SPAMMING_Groups:

            user = vk.users.get(fields='sex')[0]
            user_sex = (user.get('sex'))

            gc = gspread.service_account(filename='token.json')
            sh = gc.open("ss")
            if user_sex == 1:
                worksheet = sh.worksheet("W_Coment")  # жінка > коменти

            else:
                worksheet = sh.worksheet("M_Coment")  # чоловік > коменти

            with open('Count.txt', 'r') as f:
                lines = f.read()
                aaa = int(lines)

            # запишем файл построчно пропустив первую строку
            with open('Count.txt', 'w') as f:
                if aaa > 3:
                    aaa = 1
                else:
                    aaa = aaa+1
                f.write(str(aaa))
                f.close()

            #count_sms = input("\nНомер теми: ")
            count_sms = aaa
            group_text = worksheet.col_values(count_sms)
            group_text.pop(0)

            acc_file = open("Groups.txt", "r", encoding='utf-8')
            lista = []

            for s in acc_file:
                s = s.rstrip()
                lista = lista + [s]
            i = 0

            while(True):
                for acc in lista:
                    try:
                        i = i+1
                        print("Опрацювуємо группу "+acc+"\n")

                        grid = extract_group_id_or_name(acc)

                        if type(grid) == int:
                            acc = str(grid * -1)

                        else:
                            grid2 = vk.groups.getById(group_id=grid)
                            acc = str(grid2[0]['id'])

                        man_id = "-"+acc  # id группа, с которой будем брать посты и комментарии
                        # получаем последний пост со стены
                        postidlist = vk.wall.get(
                            owner_id=man_id, count=3, sort='desc', offset=0)

                        listt = postidlist['items']

                        for post in listt:
                            mes = (random.choice(group_text))
                            a = str(post['id'])
                            vk.wall.createComment(
                                owner_id=man_id, post_id=a, message=mes)

                            print("   Пост ✓  https://vk.com/public" +
                                  acc + "?w=wall"+man_id + "_"+a + "\n")

                            time.sleep(5)

                        procResults["group"] = procResults["group"] + 1

                        if (i > 20):
                            break
                    except vk_api.exceptions.ApiError as e:
                        print("Помилка відправлення!", e)

                print("Всі контакти оброблені")
                with open('Groups.txt', 'r') as f:
                    lines = f.readlines()

            # запишем файл построчно пропустив первую строку
                with open('Groups.txt', 'w') as f:
                    f.writelines(lines[i:])

                # Запишем результаты обработки
                with open('Results.txt', 'w') as f:
                    s = json.dump(procResults, f)

                input("Завдання завершено, натисніть Enter для виходу")
                return False

        else:
            while(True):
                try:
                    msg = random.choice(messages)

                    print(victim)
                    r = vk.messages.send(
                        peer_id=victim, message=msg, v=API_VERSION, random_id=random.randint(0, 10000))
                    print("Sent ", msg)
                    time.sleep(DELAY)
                except vk_api.exceptions.ApiError as e:
                    print("ОШИБКА!")
                    print(e)
                except Exception as e:
                    print(e)

        remove_auth_data()

        input("Завдання завершено, натисніть Enter для виходу")


def main():
    try:
        thread = MainThread()
        thread.daemon = True
        thread.start()

        while thread.is_alive():
            thread.join(1)
    except KeyboardInterrupt:
        print("Ctrl+C pressed...")

        sys.exit(1)


# -------------------------------------------
# Парсер аргументов
parser = argparse.ArgumentParser(description='Spam settings:')
parser.add_argument(
    '-d',
    '--delay',
    type=int,
    default=4,
    help='Delay (default: 4)'
)
parser.add_argument('-e', '--editmessages', action='store_true',
                    help='Use this argument to edit the message list')
parser.add_argument('-r', '--removedata', action='store_true',
                    help='Use this argument to delete auth data (login, password)')
parser.add_argument('-l', '--login', action='store', type=str,
                    help='Login to use for auth (you must also provide -p).\nOr you may provide an auth pair in format \'login:password\' (-p is not required)')
parser.add_argument('-p', '--password', action='store', type=str,
                    help='Password to use for auth (you must also provide -l).')
parser.add_argument('-t', '--target', action='store', type=int,
                    help='1 - direct messages, 2 - group posts')
args = parser.parse_args()
# -------------------------------------------

if(args.editmessages):
    if platform.system() == "Windows":
        os.system("notepad.exe " + SPAMMER_PATH + "messages.txt")
    if platform.system() == "Linux":
        os.system("nano " + SPAMMER_PATH + "messages.txt")
    print("Перезапустите спамер, чтобы обновить список сообщений")
    exit(0)

if(args.removedata):
    remove_auth_data()


# Пытаемся загрузить данные авторизации из файла
# Если не удалось, просим их ввести
load_result = False
#load_result = load_auth_data()

# Если креды переданы через cli, то используем их, иначе запрашиваем интерактивно
if(args.login):
    loginData = str(args.login)
    pair = loginData.split(':', 1)

    if(len(pair) == 1 and args.password):
        username = loginData

        if len(username) == 85:
            USE_TOKEN = True
            password = ''
        else:
            password = args.password
    elif(len(pair) == 2):
        username = pair[0]
        password = pair[1]
    else:
        print("Помилка. Невірний формат логіну/паролю.")
        exit(1)

    print("Данні авторизації отримані із командної строки\r\nЛогін: " +
          username + "\r\nПароль: " + password)

elif(load_result == False):
    username_ = input("Введіть дані від фейкового акканут (логін:пароль): ")
    auth_data = username_.split(":")
    username = auth_data[0]
    password = auth_data[1]


#     if len(username) == 85:
#         USE_TOKEN = True
#     if not USE_TOKEN:
#         password = input("Пароль: ")
#     else:
#         password = ''
    #save_auth_data = input("Сохранить эти данные авторизации? (Y/n): ")

    save_auth_data = "n"
    if(save_auth_data == "Y" or save_auth_data == "y" or save_auth_data == ""):
        auth_data['username'] = username
        auth_data['password'] = password
        do_save_auth_data()
else:
    print("Данные авторизации получены из настроек")
    username = auth_data['username']
    password = auth_data['password']
    if len(username) == 85:
        USE_TOKEN = True


def captcha_handler(captcha):
    if ANTICAPTCHA_KEY == '':
        solution = input("Решите капчу ({0}): ".format(captcha.get_url()))
        return captcha.try_again(solution)
    key = ImageToTextTask.ImageToTextTask(
        anticaptcha_key=ANTICAPTCHA_KEY, save_format='const').captcha_handler(captcha_link=captcha.get_url())

    #s = captcha.try_again(key['solution']['text'])

    s = ""
    if('solution' in key):
        s = (key['solution']['text'])
        print("Каптча: "+s)
    else:
        print(
            "Помилка обробки каптчі: [" + key['errorCode'] + "] " + key['errorDescription'])

    return captcha.try_again(s)


def auth_handler():
    key = input("Введите код подтверждения: ")
    remember_device = True
    return key, remember_device


code_country = requests.get('https://ipwhois.app/json/').json()["country_code"]

if code_country == "UA":
    input("Будь-ласка, перевірте налаштування VPN, у вас показує країну UA")
    sys.exit(1)


# -------------------------------------------
# Логинимся и получаем токен
vk_session = None

anticaptcha_api_key = '6b87e01434eed54edc689c47af0cd5f7'
#anticaptcha_api_key = input(     "API ключ от anti-captcha.com (оставьте пустым если он не нужен): ")
if anticaptcha_api_key == '':
    if USE_TOKEN:
        vk_session = vk_api.VkApi(
            token=username, auth_handler=auth_handler, app_id=API_ID, client_secret=tmp)
    else:
        vk_session = vk_api.VkApi(
            username, password, auth_handler=auth_handler, app_id=API_ID, client_secret=tmp)
else:
    ANTICAPTCHA_KEY = anticaptcha_api_key
    if USE_TOKEN:
        vk_session = vk_api.VkApi(token=username, captcha_handler=captcha_handler,
                                  auth_handler=auth_handler, app_id=API_ID, client_secret=tmp)
    else:
        vk_session = vk_api.VkApi(username, password, captcha_handler=captcha_handler,
                                  auth_handler=auth_handler, app_id=API_ID, client_secret=tmp)

try:
    vk_session.auth(token_only=True)
except vk_api.AuthError as error_msg:
    print(error_msg)

vk = vk_session.get_api()


try:
    user = vk.users.get(fields='sex')[0]
    print("Авторизувалися в :", user.get('first_name'),
          "", user.get('last_name') + "\n")
except:
    print("Помилка авторизації , перевірте дані, або візьміть інший аккаунт")
    input("Натисніть Ентер для виходу")
    sys.exit(1)


# Если цель не задана через cli, то запрашиваем интерактивно
if(args.target):
    victim = args.target
else:
    victim = input(
        "Введіть 1 для розсилання по особистим повідомленням, 2 для розсилання по группам, 3 для прикріплення відео в коментарях групи: ")


if victim == "1":
    if(check_accounts_count() == False):
        print("Будь ласка замініть файл Accounts.txt на новий")
        input("Натисніть Enter для виходу")
        exit(1)
    SPAMMING_FRIENDS = True
elif victim == "2":
    if(check_groups_count() == False):
        print("Будь ласка замініть файл Groups.txt на новий")
        input("Натисніть Enter для виходу")
        exit(1)
    SPAMMING_Groups = True
elif victim == "3":
    SPAMMING_Groups_video = True

# -------------------------------------------
# Запускатор главного потока


main()
